# Codicel

Codicel is a tool that reads an old codebase and tells you what happened in it and why.

Point it at a public GitHub repo. It reads the full commit history, not just the code as it looks today. Then it shows you:

- **Decisions.** Big changes like rewrites, migrations, or a pattern that got dropped. Each one comes with a short explanation of what changed and why, based on the actual commits.
- **Dead code.** Functions and modules that got built and then forgotten. Each one comes with a guess at what it was for.

Every claim links to the commit that backs it up. You can click through and check it on GitHub yourself. Nothing gets said without proof behind it.

## Why this is useful

Old codebases are hard to understand. The people who made the big decisions are often gone, and nothing got written down. Right now the only way to find out "why is this built this way" is to ask around or dig through history by hand.

That history already has the answer in it. It is just scattered across thousands of commits. Codicel pulls it together into something you can actually read.

## How Codex and GPT-5.6 are used

- `backend/ingest.py` clones the repo and pulls out commit and pull request data using GitPython and the GitHub API.
- `backend/analyze.py` does the cheap work first, without any AI: it groups commits by folder and time, and it checks the code for functions that are defined but never used anywhere else. This gives the model something solid to work from instead of asking it to guess from scratch.
- GPT-5.6 is only ever asked to explain the patterns we already found, not to make things up. The prompt tells it plainly: do not invent a commit, a file, or a date. If a finding does not have a real commit or file attached to it, the code throws it away before it ever reaches the screen.
- Codex was used to build the FastAPI backend, the git ingestion code, and the React frontend. The `/feedback` session ID for that build is in the submission form.

## Project layout

```
codicel/
  backend/
    main.py       # the API: /analyze, /status/{id}, /result/{id}
    ingest.py      # clones the repo, pulls commits and PRs
    analyze.py     # groups commits, finds dead code, calls the model
    models.py      # shared data shapes
    requirements.txt
    .env.example
  frontend/
    src/
      App.jsx              # the form, the progress bar, the results
      components/
        Ledger.jsx          # the timeline of findings
        EvidenceStamp.jsx   # the little badge that links to a commit
      index.css              # colors, fonts, layout
    package.json
    vite.config.js
```

## Setup

### 1. Backend

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# open .env and set OPENAI_API_KEY (see note below)
uvicorn main:app --reload --port 8000
```

A note on the API key: the code works with either OpenAI or Groq, since
Groq's API uses the same request format. This is useful if you want to
test the whole pipeline for free before OpenAI billing is set up. See the
comments in `.env.example` for both setups. For the actual submission,
switch to OpenAI's GPT-5.6, since that is what the hackathon asks you to
build with.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the local URL it prints out (usually `http://localhost:5173`). The dev server sends `/api/*` requests to the backend on port 8000. Check `vite.config.js` if you change ports.

### 3. Try it

Paste in a public GitHub repo URL and click **Excavate**. For the demo, pick a repo that is a few years old and has some abandoned experiments in it, not a small clean one. Codicel is only as interesting as the mess it has to dig through. You do not need any sample data files. Any public GitHub URL works.

## Notes for judges

- You do not need a GitHub token for a public repo unless you hit a rate limit. If you do, set `GITHUB_TOKEN` in `.env`.
- `CODICEL_MODEL` in `.env` sets which model does the reasoning. Set it to whatever model string your Build Week credits give you access to.
- Any finding without a commit or file behind it gets dropped before it reaches the screen. If a repo comes back with only a few findings, that is the accuracy check doing its job, not a bug.
